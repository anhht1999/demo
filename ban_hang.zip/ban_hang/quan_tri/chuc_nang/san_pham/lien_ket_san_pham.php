<?php 
	if(!isset($bien_bao_mat)){exit();}
?>
<div style="width:990px;text-align:left" >
	<a href="?thamso=them_san_pham" class="lk_c2" >Thêm sản phẩm</a><br>
	<a href="?thamso=quan_ly_san_pham" class="lk_c2" >Quản lý sản phẩm</a><br>
</div>